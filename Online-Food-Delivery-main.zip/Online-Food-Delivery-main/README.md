# Online-Food-Delivery

Database Name: onlinefoodphp

Developed by Sandip Mallick

Admin Login Details

Username: admin
Password: sandip@123


